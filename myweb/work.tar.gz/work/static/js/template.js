$("#tmp_add").bind("click", function(){
		
				
		$("#template_add").show();
				
		
		
		
		
		
		}
		/*
        var name = $.trim($("#username").val());
        var pwd = $.trim($("#password").val());
        
        if (name.length==0  && pwd.length==0)
        {
            alert("用xxx为空");
            //$("#EDiv1").show();
            return;
        } 
        
        var d = {username:name, password:pwd};
        $.ajax({
           type:"POST",
           url:"/login/",
           data:d, 
           dataType:"json",
           success:function(data, textStatus){
                if (data.message != "ok") {
                    alert(data.message);  
                }
                else{
                    $("#loginform").submit();
                }
           }
        });
    }
    */
);