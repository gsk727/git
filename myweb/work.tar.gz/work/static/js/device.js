$("#okBtn").bind("click",function(){
        var local= $.trim($("#localInfo").val());

        var id = $.trim($("#IDInfo").val());
        var des = $.trim($("#desInfo").val());
        var fly = $.trim($("#flightInfo").val());

        alert(local);
       }
);
