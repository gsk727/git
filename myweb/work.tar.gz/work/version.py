import math
VERSION = math.pi
