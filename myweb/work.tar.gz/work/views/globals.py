from mode.base import BaseMode
# from werkzeug.local import LocalProxy
from flask import g

# base = g.base = BaseMode()
